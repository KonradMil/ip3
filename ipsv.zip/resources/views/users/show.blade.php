@extends('layouts.app')

@section('content')
    {!! $user !!}

    @stop