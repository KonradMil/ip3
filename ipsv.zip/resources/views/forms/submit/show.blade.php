@extends('layouts.app')

@section('content')
<form action="{{url('forms/submit/submitnew')}}" method="post">
    @foreach($form as $forma)
        <h3>{{$forma['name']}}</h3>
        
            <input name="id" hidden value="{{ $forma['id'] }}"/>
            {!! $contents !!}
           
    @endforeach
<div class='clearfix'></div>
<div class='row'>
 <input type="submit" value="Submit">
</div>
        </form>
@endsection
