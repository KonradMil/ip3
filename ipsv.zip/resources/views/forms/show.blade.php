@extends('layouts.app')

@section('content')

   {!! $form !!}
@stop