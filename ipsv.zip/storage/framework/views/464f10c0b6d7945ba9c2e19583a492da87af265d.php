<html>
<body>
<h1>Laravel Quickstart</h1>

<?php echo $__env->yieldContent('content'); ?>
</body>
</html>