

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('forms/submit/submitnew')); ?>" method="post">
    <?php foreach($form as $forma): ?>
        <h3><?php echo e($forma['name']); ?></h3>
        
            <input name="id" hidden value="<?php echo e($forma['id']); ?>"/>
            <?php echo $contents; ?>

           
    <?php endforeach; ?>
<div class='clearfix'></div>
<div class='row'>
 <input type="submit" value="Submit">
</div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>