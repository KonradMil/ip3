

<?php $__env->startSection('content'); ?>
    <div class="row-fluid">

<?php if(Session::has('success')): ?>
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <strong>Success!</strong> <?php echo e(Session::get('message', '')); ?>

    </div>
    <?php endif; ?>
    </div>


    <?php $__env->stopSection(); ?>