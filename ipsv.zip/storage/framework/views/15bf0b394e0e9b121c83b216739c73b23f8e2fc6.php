<?php $__env->startSection('content'); ?>
    <div class="col-md-6">
        <?php foreach($sms_sent as $forma): ?>
            <h4>System</h4>
           <p>
               <?php echo $forma{'content'}; ?>

           </p>
            <p><i><?php echo $forma['created_at']; ?></i></p>
        <?php endforeach; ?>
    </div>
    <div class="col-md-6">
        <?php foreach($sms_rec as $form): ?>
            <h4>User</h4>
            <p>
                <?php echo $form{'content'}; ?>

            </p>
            <p><i><?php echo $form['created_at']; ?></i></p>
        <?php endforeach; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>