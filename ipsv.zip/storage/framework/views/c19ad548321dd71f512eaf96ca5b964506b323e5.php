

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Edit</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/users/edited')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Name</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e($user['name']); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <input type="hidden" name="id" value="<?php echo e($user['id']); ?>">
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">E-Mail Address</label>

                                <div class="col-md-6">
                                    <input type="email" class="form-control" name="email" value="<?php echo e($user['email']); ?>">

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Phone Number</label>

                                <div class="col-md-6">
                                    <input type="tel" class="form-control" name="phone" value="<?php echo e($user['phone_nr']); ?>">

                                    <?php if($errors->has('phone')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input type="password" class="form-control" name="password" value="">

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has($user['roles']) ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Role</label>


                                <div class="col-md-6">
                                    <div class="radio">
                                        <?php if($user['roles']== 'admin'): ?>

                                        <label><input type="radio" name="role" checked="checked" value="admin">Admin</label>
                                            <?php else: ?>
                                            <label><input type="radio" name="role" value="admin">Admin</label>
                                            <?php endif; ?>
                                    </div>
                                    <div class="radio">
                                        <?php if($user['roles'] == 'user'): ?>
                                            <label><input type="radio" name="role" checked="checked" value="user">User</label>
                                        <?php else: ?>
                                            <label><input type="radio" name="role" value="user">User</label>
                                        <?php endif; ?>

                                    </div>
                                    <div class="radio">
                                        <?php if($user['roles'] == 'manager'): ?>
                                            <label><input type="radio" name="role" checked="checked" value="manager">Manager</label>
                                        <?php else: ?>
                                            <label><input type="radio" name="role" value="manager">Manager</label>
                                        <?php endif; ?>

                                    </div>

                                    <?php if($errors->has($user['roles'])): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('roles')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('groups') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Group</label>


                                <div class="col-md-6">
                                    <?php $ar = []; ?>
                                        <?php foreach($groups as $group): ?>
                                        <?php foreach($user_groups as $user_group): ?>
                                            <?php if($group['id'] == $user_group['id'] ): ?>
                                                <?php array_push($ar,$user_group['id']); ?>
                                            <?php endif; ?>
                                            <?php endforeach; ?>
                                        <?php endforeach; ?>
                                        <?php foreach($groups as $group): ?>
                                            <?php if(in_array($group['id'],$ar)): ?>
                                        <input type="checkbox" value="<?php echo e($group['id']); ?>" name="group[]" checked><?php echo e($group['name']); ?></input>
                                                <?php else: ?>
                                                <input type="checkbox" value="<?php echo e($group['id']); ?>" name="group[]"><?php echo e($group['name']); ?></input>
                                            <?php endif; ?>
                                        <?php endforeach; ?>


                                <?php if($errors->has('group')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('group')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>