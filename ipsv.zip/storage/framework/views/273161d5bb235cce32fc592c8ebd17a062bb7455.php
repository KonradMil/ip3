<?php $__env->startSection('content'); ?>
    <?php foreach($form as $forma): ?>
        <h3><?php echo e($forma['name']); ?></h3>
        <form action="<?php echo e(url('forms/submit/submitnew')); ?>" method="post">
            <input name="id" hidden value="<?php echo e($forma['id']); ?>">
            <?php echo $forma['content']; ?>

            <input type="submit" value="Submit">
        </form>
    <?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script>
    <?php echo $hiddenDivBeginning; ?>

</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>