<?php

return [

    /*
    |--------------------------------------------------------------------------
    | API Stuff
    |--------------------------------------------------------------------------
    |
    | Set the public key, private key and site id provided by Pusher
    |
    */
    'app_key'    => env('PUSHER_KEY'),
    'app_secret'   => env('PUSHER_SECRET'),
    'app_id'       => env('PUSHER_APP_ID'),

    /*
    |--------------------------------------------------------------------------
    | Options
    |--------------------------------------------------------------------------
    |
    | Various options.
    |
    */
    'options'       => [

        'scheme' => 'http', // e.g. http or https
        'host' => 'api-eu.pusher.com', // the host e.g. api.pusherapp.com. No trailing forward slash.
        'port' => 80, // the http port
        'timeout' => 30, // the HTTP timeout
        'encrypted' => false, // quick option to use scheme of https and port 443.
        'debug' => true, // You can optionally turn on debugging for all requests by setting debug to true.

    ],

];
