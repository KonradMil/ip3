<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_group extends Model
{
    protected $fillable = [
        'group_id', 'user_id'
    ];
}
